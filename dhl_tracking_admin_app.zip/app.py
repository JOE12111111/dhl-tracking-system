
from flask import Flask, render_template, request, redirect, url_for, flash, session
from dotenv import load_dotenv
import os

load_dotenv()

app = Flask(__name__)
app.secret_key = os.getenv("SECRET_KEY", "your_default_secret_key")

ADMIN_USERNAME = os.getenv("ADMIN_USERNAME", "admin")
ADMIN_PASSWORD = os.getenv("ADMIN_PASSWORD", "secret123")

fake_tracking_db = {
    "DHL123456789": {"status": "In Transit", "location": "Lagos"},
    "DHL987654321": {"status": "Delivered", "location": "Abuja"},
    "DHL000000001": {"status": "Pending Pickup", "location": "Port Harcourt"}
}

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/result")
def result():
    tracking_id = request.args.get("tracking_id", "").strip()
    if not tracking_id:
        flash("Please enter a tracking ID.", "error")
        return redirect(url_for("home"))

    tracking_info = fake_tracking_db.get(tracking_id.upper())
    if tracking_info:
        return render_template("result.html", tracking_id=tracking_id, info=tracking_info)
    else:
        flash("Tracking ID not found.", "error")
        return redirect(url_for("home"))

@app.route("/admin/login", methods=["GET", "POST"])
def admin_login():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]
        if username == ADMIN_USERNAME and password == ADMIN_PASSWORD:
            session["admin"] = True
            flash("Logged in successfully", "success")
            return redirect(url_for("admin_dashboard"))
        else:
            flash("Invalid credentials", "error")
    return render_template("admin_login.html")

@app.route("/admin/dashboard")
def admin_dashboard():
    if not session.get("admin"):
        flash("Please log in as admin.", "error")
        return redirect(url_for("admin_login"))
    return render_template("admin_dashboard.html", tracking_db=fake_tracking_db)

@app.route("/admin/logout")
def admin_logout():
    session.pop("admin", None)
    flash("Logged out successfully", "success")
    return redirect(url_for("admin_login"))

if __name__ == "__main__":
    app.run(debug=True)
